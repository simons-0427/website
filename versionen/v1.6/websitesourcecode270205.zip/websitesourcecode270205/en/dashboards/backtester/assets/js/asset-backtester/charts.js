import { RANK_METRICS, initialRanking, compareRankedMetrics } from './ranking.js?v=20261028-v13y';
import {
  formatCompactMoney,
  formatDate,
  formatEuro,
  formatPercent,
  formatPlainPercent,
  formatSourceValue,
} from './formatters.js?v=20261028-v13y';

const STYLES = {
  sp500: { color: '#6ee7b7', dividendColor: '#38bdf8', pointStyle: 'circle' },
  bitcoin: { color: '#818cf8', pointStyle: 'rectRot' },
  gold: { color: '#f6c85f', pointStyle: 'rect' },
  msci_world: { color: '#f472b6', dividendColor: '#22d3ee', pointStyle: 'triangle' },
  de_real_estate: { color: '#a3e635', dividendColor: '#d9f99d', pointStyle: 'crossRot' },
  us_real_estate: { color: '#fb923c', dividendColor: '#fdba74', pointStyle: 'star' },
  dax: { color: '#ef4444', dividendColor: '#fca5a5', pointStyle: 'cross' },
  eurostoxx50: { color: '#3b82f6', dividendColor: '#93c5fd', pointStyle: 'triangle' },
  global_ig_bonds: { color: '#c4b5fd', pointStyle: 'rectRounded' },
  global_ig_bonds_unhedged: { color: '#a78bfa', pointStyle: 'rectRot' },
  commodities: { color: '#2dd4bf', pointStyle: 'crossRot' },
  euro_money_market: { color: '#e2e8f0', pointStyle: 'circle' },
  us_money_market: { color: '#60a5fa', pointStyle: 'star' },
};

function positiveChartValue(value) {
  const number = Number(value);
  return Number.isFinite(number) && number > 0 ? number : null;
}

export function singleTooltipLines(series, point) {
  const hasRentalCashflow = Boolean(series.rentalCashflowAdjustment?.applied);
  const lines = [
    `${series.dividendAdjustment?.applied
      ? 'Total return incl. dividends'
      : (hasRentalCashflow ? 'Total return incl. net rental cash flow' : 'Since start of period')}: ${formatPercent(point.returnPct)}`,
  ];
  lines.push(`From ${formatEuro(10000)}: ${formatEuro(point.portfolioValue)}`);
  if (series.dividendAdjustment?.applied) {
    lines.push(series.dividendAdjustment.method === 'annual_yield_december_31'
      ? 'Method: annual dividend on 31 December'
      : 'Method: monthly Multpl dividend calculation');
  }
  if (hasRentalCashflow) {
    lines.push(`Net rental cash flow: ${formatPlainPercent(series.rentalCashflowAdjustment.annualNetCashflowPct)} p.a.; not reinvested`);
  }
  if (series.terAdjustment?.applied) {
    lines.push(`TER: ${formatPlainPercent(series.terAdjustment.annualTerPct)} p.a.`);
    lines.push(`Estimated TER effect to date: −${formatEuro(point.terCostAmount || 0)}`);
  }
  return lines;
}

export function comparisonTooltipReturn(item) {
  const point = item?.dataset?.metaSeries?.points?.[item.dataIndex];
  if (item?.dataset?.comparisonVariant === 'price') {
    const provided = Number(point?.priceOnlyReturnPct);
    if (point?.priceOnlyReturnPct!=null && Number.isFinite(provided)) return provided;
    const startValue = Number(item?.dataset?.data?.[0]);
    const currentValue = Number(item?.raw);
    return startValue > 0 && Number.isFinite(currentValue)
      ? (currentValue / startValue - 1) * 100
      : Number.NEGATIVE_INFINITY;
  }
  const value = Number(point?.returnPct);
  if(point?.returnPct!=null && Number.isFinite(value))return value;
  const initial=(item?.dataset?.data || []).find(v=>v!=null && Number.isFinite(Number(v)) && Number(v)>0);
  return item?.raw!=null && initial!=null && Number.isFinite(Number(item.raw))?(Number(item.raw)/Number(initial)-1)*100:Number.NEGATIVE_INFINITY;
}

export function comparisonTooltipLines(item) {
              const series = item.dataset.metaSeries;
              const point = series.points[item.dataIndex];
              if (series.isPortfolio) return [item.dataset.label + ': ' + formatEuro(point.portfolioValue) + '; ' + formatPercent(point.returnPct)];
              const returnKind = series.inflationAdjustment?.applied ? 'real return' : 'return';
              if (item.dataset.comparisonVariant === 'price') {
                const lines = [`${item.dataset.label}: ${formatEuro(item.raw)}; ${returnKind} ${formatPercent(comparisonTooltipReturn(item))}; Index ${formatSourceValue(point.sourceValue, series.currency)}`];
                if (series.taxAdjustment?.applied) {
                  lines.push(`Tax model: ${point.priceOnlyTaxLabel}; ${formatEuro(point.priceOnlyTaxAmount || 0)}`);
                }
                if (series.terAdjustment?.applied) {
                  lines.push(`TER: ${formatPlainPercent(series.terAdjustment.annualTerPct)} p.a.`);
                }
                return lines;
              }
              const lines = [item.dataset.comparisonVariant === 'dividend'
                ? `${item.dataset.label}: ${formatEuro(point.portfolioValue)}; ${returnKind} ${formatPercent(point.returnPct)}`
                : `${item.dataset.label}: ${formatEuro(point.portfolioValue)}; ${returnKind} ${formatPercent(point.returnPct)}; price ${formatSourceValue(point.sourceValue, series.currency)}`];
              if (series.taxAdjustment?.applied) {
                lines.push(`Tax model: ${point.taxLabel}; ${formatEuro(point.taxAmount || 0)}`);
              }
              if (series.terAdjustment?.applied) {
                lines.push(`TER: ${formatPlainPercent(series.terAdjustment.annualTerPct)} p.a.; effect −${formatEuro(point.terCostAmount || 0)}`);
              }
              return lines;
}
export function tooltipRankingMetrics(item){
  const series=item.dataset.metaSeries,metrics={...(item.dataset.comparisonVariant==='price'?series.priceOnlyMetrics:series.metrics)};
  metrics.totalReturnPct=comparisonTooltipReturn(item);metrics.finalValue=item.raw;
  const initial=item.dataset.data.find(v=>v!=null && Number.isFinite(Number(v)) && Number(v)>0);
  metrics.absoluteReturn=initial==null?null:Number(item.raw)-Number(initial);return metrics;
}
export function compareComparisonTooltipItems(a,b,ranking=initialRanking()){return compareRankedMetrics(tooltipRankingMetrics(a),tooltipRankingMetrics(b),ranking);}
function externalComparisonTooltip({chart,tooltip},ranking){
  if(typeof document==='undefined')return;
  let tip=chart.$comparisonTooltip;
  if(!tooltip || tooltip.opacity===0){
    if(tip && !tip.matches(':hover')){clearTimeout(chart.$comparisonTooltipTimer);chart.$comparisonTooltipTimer=setTimeout(()=>{if(!tip.matches(':hover'))tip.hidden=true;},180);}
    return;
  }
  if(!tip){
    tip=document.createElement('div');tip.className='asset-backtester__comparison-tooltip';tip.dataset.comparisonTooltip='';tip.setAttribute('role','tooltip');
    tip.addEventListener('mouseenter',()=>clearTimeout(chart.$comparisonTooltipTimer));
    tip.addEventListener('mouseleave',()=>{tip.hidden=true;});document.body.append(tip);chart.$comparisonTooltip=tip;
  }
  clearTimeout(chart.$comparisonTooltipTimer);tip.hidden=false;
  const title=document.createElement('strong');title.className='asset-backtester__tooltip-title';title.textContent=(tooltip.title || []).join(' ');
  const list=document.createElement('div');list.className='asset-backtester__tooltip-list';
  for(const item of tooltip.dataPoints || []){
    if(item.raw==null || !Number.isFinite(Number(item.raw)))continue;
    const row=document.createElement('div');row.className='asset-backtester__tooltip-row';row.dataset.tooltipPortfolio=String(Boolean(item.dataset.metaSeries?.isPortfolio));
    const dot=document.createElement('span');dot.className='asset-backtester__tooltip-key';dot.style.backgroundColor=item.dataset.borderColor;
    const text=document.createElement('div');const lines=comparisonTooltipLines(item);
    for(const [index,line] of lines.entries()){const part=document.createElement(index===0?'div':'small');part.textContent=line;text.append(part);}
    const criterion=ranking[0]?.key;
    if(criterion && criterion!=='totalReturnPct'){
      const value=tooltipRankingMetrics(item)[criterion],part=document.createElement('small'),language=document.documentElement.lang==='en'?'en':'de';
      const display=value==null || !Number.isFinite(Number(value))?'–':['finalValue','absoluteReturn'].includes(criterion)?formatEuro(value):Number(value).toLocaleString(language==='en'?'en-GB':'de-DE',{maximumFractionDigits:3})+(['cagrPct','annualizedVolatilityPct','maxDrawdownPct','positiveDaysPct','bestDayPct','worstDayPct'].includes(criterion)?' %':'');
      part.textContent=RANK_METRICS[criterion][language]+': '+display;text.append(part);
    }
    row.append(dot,text);list.append(row);
  }
  tip.replaceChildren(title,list);
  const box=chart.canvas.getBoundingClientRect(),width=Math.min(460,window.innerWidth-24);tip.style.width=width+'px';
  const x=box.left+(tooltip.caretX || 0)*(box.width/chart.width),y=box.top+(tooltip.caretY || 0)*(box.height/chart.height);
  tip.style.left=Math.max(12,Math.min(x+14,window.innerWidth-width-12))+'px';
  const height=tip.getBoundingClientRect().height;
  tip.style.top=Math.max(12,Math.min(y+14,window.innerHeight-height-12))+'px';
}
export class ChartManager {
  constructor(ChartClass = window.Chart) {
if (!ChartClass) throw new Error('Chart.js could not be loaded.');
    this.Chart = ChartClass;
    this.instances = new Map();
    this.Chart.defaults.font.family = "'DM Sans', sans-serif";
    this.Chart.defaults.color = '#64748b';
  }

  single(canvas, series) {
    const style = STYLES[series.slug] || STYLES.sp500;
    const points = series.points;
    const hasDividendLine = Boolean(series.dividendAdjustment?.applied);
    const hasRentalCashflowLine = Boolean(series.rentalCashflowAdjustment?.applied);
    const hasTerLine = Boolean(series.terAdjustment?.applied);
    const hasAdjustedLine = hasDividendLine || hasRentalCashflowLine || hasTerLine;
    const priceColor = hasAdjustedLine ? (style.dividendColor || '#94a3b8') : style.color;
    const datasets = [{
      label: hasAdjustedLine ? 'Price index' : series.displayName,
      data: points.map((point) => positiveChartValue(point.sourceValue)),
      borderColor: priceColor,
      borderDash: [],
      backgroundColor: hasAdjustedLine ? 'transparent' : `${priceColor}18`,
      borderWidth: 2.2,
      pointRadius: 0,
      pointHoverRadius: 4,
      pointHoverBorderWidth: 2,
      pointHoverBackgroundColor: '#16161f',
      pointHoverBorderColor: priceColor,
      fill: !hasAdjustedLine,
      tension: 0,
      spanGaps: true,
      metaPoints: points,
    }];
    if (hasAdjustedLine) {
      const adjustedLabel = hasRentalCashflowLine
        ? 'Price + net rental cash flow'
        : (hasDividendLine ? 'Price + dividends' : series.displayName);
      datasets.push({
        label: hasTerLine ? `${adjustedLabel} after TER` : adjustedLabel,
        data: points.map((point) => positiveChartValue(
          hasTerLine
            ? point.terAdjustedSourceValue
            : (hasRentalCashflowLine
            ? point.rentalCashflowAdjustedSourceValue
            : point.dividendAdjustedSourceValue),
        )),
        borderColor: style.color,
        borderDash: [],
        backgroundColor: 'transparent',
        borderWidth: 2,
        pointRadius: 0,
        pointHoverRadius: 4,
        pointHoverBorderWidth: 2,
        pointHoverBackgroundColor: '#16161f',
        pointHoverBorderColor: style.color,
        fill: false,
        tension: 0,
        spanGaps: true,
        metaPoints: points,
      });
    }

    return this.#replace(canvas, {
      type: 'line',
      data: { labels: points.map((point) => point.date), datasets },
      options: this.#options({
        currencyAxis: series.currency !== 'PTS',
        showLegend: hasAdjustedLine,
        tooltip: {
          callbacks: {
            title: (items) => formatDate(points[items[0]?.dataIndex]?.date),
            label: (item) => `${item.dataset.label}: ${formatSourceValue(item.raw, series.currency)}`,
            afterBody: (items) => singleTooltipLines(
              series,
              points[items[0]?.dataIndex],
            ),
            footer: (items) => {
              const point = points[items[0]?.dataIndex];
              return point.isCarriedForward
                ? `Carried forward from the last observed value on ${formatDate(point.lastRawObservationDate)}`
                : `Observed value: ${formatDate(point.lastRawObservationDate)}`;
            },
          },
        },
      }),
    });
  }

  comparison(canvas, seriesList, {
    showSp500Dividend = true,
    showSp500Price = false,
    showMsciWorldDividend = false,
    showMsciWorldPrice = false,
    showDaxDividend = false,
    showDaxPrice = false,
    showEuroStoxx50Dividend = false,
    showEuroStoxx50Price = false,
    ranking = initialRanking(),
  } = {}) {
    const labels = [...new Set(seriesList.flatMap((series) => series.points.map((point) => point.date)))].sort();
    seriesList = seriesList.map((series) => {
      const byDate = new Map(series.points.map((point) => [point.date, point]));
      return { ...series, points: labels.map((date) => byDate.get(date) || { date, portfolioValue: null, sourceValue: null, returnPct: null }) };
    });
    const datasets = seriesList.flatMap((series) => {
      const style = series.portfolioStyle || STYLES[series.slug] || STYLES.sp500;
      const qualifiers = [];
      if (series.inflationAdjustment?.applied) qualifiers.push('real');
      if (series.taxAdjustment?.applied) qualifiers.push('after tax');
      const createDataset = (label, data, color, variant = 'total') => ({
        label: qualifiers.length ? `${label} (${qualifiers.join(', ')})` : label,
        data,
        borderColor: color,
        backgroundColor: 'transparent',
        borderWidth: variant === 'dividend' ? 2.6 : 2.2,
        borderDash: series.isPortfolio ? (style.reference ? [3, 4] : [7, 3]) : [],
        pointStyle: style.pointStyle,
        pointRadius: 0,
        pointHoverRadius: 4,
        pointHoverBorderWidth: 2,
        pointHoverBackgroundColor: '#16161f',
        pointHoverBorderColor: color,
        tension: 0,
        spanGaps: true,
        metaSeries: series,
        comparisonVariant: variant,
      });

      const firstPoint = series.points.find((p) => p.portfolioValue > 0);
      const firstSourceValue = Number(firstPoint?.sourceValue);
      const firstPortfolioValue = Number(firstPoint?.portfolioValue);
      const priceOnlyData = series.points.map((point) => {
        const provided = positiveChartValue(point.priceOnlyPortfolioValue);
        if (provided !== null) return provided;
        const sourceValue = Number(point.sourceValue);
        return firstSourceValue > 0 && firstPortfolioValue > 0 && sourceValue > 0
          ? positiveChartValue(firstPortfolioValue * sourceValue / firstSourceValue)
          : null;
      });
      const totalData = ['de_real_estate', 'us_real_estate'].includes(series.slug)
        ? priceOnlyData
        : series.points.map((point) => positiveChartValue(point.portfolioValue));
      const dividendView = ({
        sp500: {
          showTotal: showSp500Dividend,
          showPrice: showSp500Price,
          totalLabel: 'S&P 500',
          priceLabel: 'S&P 500 price only',
        },
        msci_world: {
          showTotal: showMsciWorldDividend,
          showPrice: showMsciWorldPrice,
          totalLabel: 'MSCI World',
          priceLabel: 'MSCI World price only',
        },
        dax: {
          showTotal: showDaxDividend,
          showPrice: showDaxPrice,
          totalLabel: 'DAX',
          priceLabel: 'DAX price only',
        },
        eurostoxx50: {
          showTotal: showEuroStoxx50Dividend,
          showPrice: showEuroStoxx50Price,
          totalLabel: 'EURO STOXX 50',
          priceLabel: 'EURO STOXX 50 price only',
        },
      })[series.slug] || null;
      const dividendApplied = series.dividendAdjustment?.applied;
      if (!dividendView || !dividendApplied) {
        return [createDataset(series.displayName, totalData, style.color)];
      }

      const dividendDatasets = [];
      if (dividendView.showTotal) {
        dividendDatasets.push(createDataset(dividendView.totalLabel, totalData, style.color, 'dividend'));
      }
      if (dividendView.showPrice) {
        dividendDatasets.push(createDataset(dividendView.priceLabel, priceOnlyData, style.dividendColor, 'price'));
      }
      return dividendDatasets;
    });

    datasets.sort((a,b)=>{
      const item=dataset=>{const index=dataset.data.findLastIndex(v=>v!=null && Number.isFinite(Number(v)));return {dataset,dataIndex:index,raw:dataset.data[index]};};
      return compareComparisonTooltipItems(item(a),item(b),ranking);
    });
    return this.#replace(canvas, {
      type: 'line',
      plugins:[{id:'comparison-tooltip-cleanup',afterDestroy(chart){clearTimeout(chart.$comparisonTooltipTimer);chart.$comparisonTooltip?.remove();}}],
      data: { labels, datasets },
      options: this.#options({
        currencyAxis: true,
        showLegend: true,
        tooltip: {
          enabled: false,
          external: context=>externalComparisonTooltip(context,ranking),
          itemSort: (a,b)=>compareComparisonTooltipItems(a,b,ranking),
          callbacks: {
            title: (items) => formatDate(labels[items[0]?.dataIndex]),
            label: comparisonTooltipLines,
          },
        },
      }),
    });
  }

  destroyAll() {
    this.instances.forEach((chart) => chart.destroy());
    this.instances.clear();
  }

  #replace(canvas, config) {
    const key = canvas.id;
    this.instances.get(key)?.destroy();
    const instance = new this.Chart(canvas.getContext('2d'), config);
    this.instances.set(key, instance);
    return instance;
  }

  #options({ currencyAxis, showLegend = false, tooltip }) {
    return {
      responsive: true,
      maintainAspectRatio: false,
      animation: { duration: 180 },
      normalized: true,
      interaction: { mode: 'index', intersect: false, axis: 'x' },
      plugins: {
        legend: {
          display: showLegend,
          position: 'bottom',
          labels: { usePointStyle: true, boxWidth: 8, boxHeight: 8, padding: 18, color: '#94a3b8' },
          onClick: () => {},
        },
        tooltip: {
          enabled: true,
          mode: 'index',
          intersect: false,
          backgroundColor: 'rgba(12,12,15,.96)',
          titleColor: '#e2e8f0',
          bodyColor: '#cbd5e1',
          borderColor: '#2b2b40',
          borderWidth: 1,
          padding: 11,
          displayColors: showLegend,
          usePointStyle: true,
          ...tooltip,
        },
        decimation: { enabled: true, algorithm: 'min-max' },
      },
      scales: {
        x: {
          grid: { display: false },
          border: { color: '#1e1e2e' },
          ticks: {
            color: '#64748b',
            maxTicksLimit: 7,
            maxRotation: 0,
            callback(_value, index) { return formatDate(this.getLabelForValue(index)).slice(3); },
          },
        },
        y: {
          type: 'logarithmic',
          grid: { color: 'rgba(100,116,139,.12)' },
          border: { display: false },
          ticks: {
            color: '#64748b',
            maxTicksLimit: 6,
            callback: (value) => currencyAxis
              ? formatCompactMoney(value)
              : Number(value).toLocaleString('de-DE', { notation: 'compact', maximumFractionDigits: 2 }),
          },
        },
      },
    };
  }
}
